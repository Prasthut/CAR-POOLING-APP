package com.example.car_pooling_app.models;

public interface UserData {

    public void getUserData();
}
