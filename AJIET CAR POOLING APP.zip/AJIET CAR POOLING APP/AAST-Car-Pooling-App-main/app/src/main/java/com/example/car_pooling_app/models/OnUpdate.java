package com.example.car_pooling_app.models;

public interface OnUpdate {

    public void finishTask();


}
